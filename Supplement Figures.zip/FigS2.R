library(dplyr)
library(purrr)
library(ggplot2)

# Make sure Serotype is defined in your data
merged_data <- merged_data %>%
  mutate(
    Serotype = gsub("[^0-9]", "", Genotype)
  )

# --- Compute Pearson correlations for each Serotype × Mosquito_strain ---
cor_summary <- merged_data %>%
  group_by(Serotype, Mosquito_strain) %>%
  summarise(
    cor_test = list(cor.test(
      dissemination_total * 100,
      dissemination_per_infected * 100,
      method = "pearson"
    )),
    .groups = "drop"
  ) %>%
  mutate(
    r = map_dbl(cor_test, ~ round(.x$estimate, 2)),
    p = map_dbl(cor_test, ~ .x$p.value),
    stars = case_when(
      p < 0.001 ~ "***",
      p < 0.01 ~ "**",
      p < 0.05 ~ "*",
      TRUE ~ "ns"
    ),
    label = paste0("r = ", r, " ", stars),
    x = 10,  # placement
    y = 95
  )

print(cor_summary)

# --- Create the 4x3 correlation plot ---
f_corr <- ggplot(
  merged_data,
  aes(
    x = dissemination_total * 100,
    y = dissemination_per_infected * 100,
    fill = Genotype
  )
) +
  # Points (colored by Genotype, black outline)
  geom_point(shape = 21, color = "black", size = 3, alpha = 0.9) +
  # One regression line per facet
  geom_smooth(
    aes(group = 1),
    method = "lm",
    se = FALSE,
    color = "black",
    linetype = "dashed",
    linewidth = 0.8
  ) +
  # Add r and significance to each facet
  geom_text(
    data = cor_summary,
    aes(x = x, y = y, label = label),
    inherit.aes = FALSE,
    size = 4,
    hjust = 0,
    fontface = "bold"
  ) +
  # Facet layout: Serotype (rows) × Mosquito strain (columns)
  facet_grid(Serotype ~ Mosquito_strain, scales = "fixed") +
  scale_fill_manual(values = Genotype_colors) +
  scale_y_continuous(limits = c(0, 100)) +
  scale_x_continuous(limits = c(0, 100)) +
  theme_classic() +
  labs(
    x = "Dissemination rate (relative to all exposed)",
    y = "Dissemination rate (relative to infected)",
    fill = "Genotype",
    title = "Correlation between two dissemination metrics"
  ) +
  theme(
    legend.position = "right",
    legend.key.size = unit(0.5, "cm"),
    text = element_text(size = 12),
    strip.text = element_text(face = "bold"),
    plot.title = element_text(face = "bold", hjust = 0.5)
  )

f_corr
