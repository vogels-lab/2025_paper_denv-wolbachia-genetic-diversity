library(readxl)
library(dplyr)
library(tidyr)
library(ggplot2)
library(ggpubr)
library(ggbeeswarm)

# ------------------------
# Define colors and labels
# ------------------------
Serotype_colors <- c(
  "1" = "#227DCB",
  "2" = "#b020e0",
  "3" = "#ffce9d",
  "4" = "#954226"
)
expected_strains <- c("WT", "wAlbB", "wMelM")
serotype_labels <- c(
  "1" = "DENV-1",
  "2" = "DENV-2",
  "3" = "DENV-3",
  "4" = "DENV-4"
)

# ------------------------
# Load and preprocess data
# ------------------------
Dataset_final <- read_xlsx("~/Desktop/Extracted_data/DENV1-4_extractedPCR_Clean.xlsx", sheet = "Sheet1")

Dataset_final <- Dataset_final %>%
  mutate(
    `GE/uL_Bodies` = if_else(`Infection(<38)` == 0 & `Dissemination(<38)` == 0,
                             1,
                             as.numeric(`GE/uL_Bodies`)),
    `GE/uL_Legs` = if_else(`Infection(<38)` == 0 & `Dissemination(<38)` == 0,
                           1,
                           as.numeric(`GE/uL_Legs`))
  )

Dataset_status <- Dataset_final %>%
  mutate(
    Serotype = factor(Serotype),
    Mosquito_strain = if_else(Mosquito_strain == "wMel", "wMelM", Mosquito_strain),
    Mosquito_strain = factor(Mosquito_strain, levels = expected_strains),
    Category = case_when(
      `Infection(<38)` == 1 & `Dissemination(<38)` == 1 ~ "Diss.",
      `Infection(<38)` == 1 & `Dissemination(<38)` == 0 ~ "Un-Diss.",
      `Infection(<38)` == 0 ~ "Un-Inf.",
      TRUE ~ NA_character_
    ),
    Category = factor(Category, levels = c("Diss.", "Un-Diss.", "Un-Inf.")),
    GE_log10_Bodies = log10(pmax(as.numeric(`GE/uL_Bodies`), 0.034))
  ) %>%
  drop_na(GE_log10_Bodies)

# ------------------------
# Compute medians and CIs
# ------------------------
CI_status <- Dataset_status %>%
  group_by(Mosquito_strain, Category, Serotype) %>%
  summarise(
    x4 = quantile(GE_log10_Bodies, 0.025, na.rm = TRUE),
    ratio2 = quantile(GE_log10_Bodies, 0.5, na.rm = TRUE),
    x5 = quantile(GE_log10_Bodies, 0.975, na.rm = TRUE),
    .groups = "drop"
  )

# ------------------------
# Pairwise Wilcoxon + BH adjustment (per strain × serotype)
# ------------------------
pval_df_status <- data.frame()
for (strain in expected_strains) {
  for (sero in unique(Dataset_status$Serotype)) {
    sub_data <- Dataset_status %>%
      filter(Mosquito_strain == strain, Serotype == sero)
    
    if (nrow(sub_data) > 2 && length(unique(sub_data$Category)) > 1) {
      pairwise_result <- pairwise.wilcox.test(
        sub_data$GE_log10_Bodies,
        sub_data$Category,
        p.adjust.method = "BH"
      )
      
      res <- as.data.frame(as.table(pairwise_result$p.value))
      colnames(res) <- c("group1", "group2", "p.adj")
      res <- res %>%
        filter(!is.na(p.adj)) %>%
        mutate(Mosquito_strain = strain, Serotype = sero)
      
      pval_df_status <- bind_rows(pval_df_status, res)
    }
  }
}

pval_df_status <- pval_df_status %>%
  mutate(
    y.position = 6,
    label = case_when(
      p.adj < 0.0001 ~ "***",
      p.adj < 0.01 ~ "**",
      p.adj < 0.05 ~ "*",
      TRUE ~ "ns"
    ),
    Serotype = factor(Serotype, levels = levels(Dataset_status$Serotype)),
    Mosquito_strain = factor(Mosquito_strain, levels = expected_strains)
  )

# ------------------------
# Plot
# ------------------------
Figure_DisseminationStatus <- ggplot(Dataset_status,
                                     aes(x = Category, y = GE_log10_Bodies, fill = Serotype)) +
  
  geom_quasirandom(
    width = 0.25, varwidth = FALSE,
    shape = 21, color = "black",
    size = 2.5, alpha = 0.9
  ) +
  
  geom_errorbar(
    data = CI_status,
    aes(x = Category, ymin = x4, ymax = x5),
    width = 0.1, inherit.aes = FALSE, color = "black", linewidth = 0.5
  ) +
  
  geom_crossbar(
    data = CI_status,
    aes(x = Category, y = ratio2, ymin = ratio2, ymax = ratio2),
    width = 0.5, color = "black", linewidth = 0.7, alpha = 0.8,
    inherit.aes = FALSE
  ) +
  
  facet_grid(
    Serotype ~ Mosquito_strain,
    labeller = labeller(Serotype = as_labeller(serotype_labels)),
    scales = "fixed"
  ) +
  
  scale_fill_manual(values = Serotype_colors, labels = serotype_labels) +
  scale_y_continuous(breaks = seq(0, 6.5, 1), limits = c(0, 6.5)) +
  
  labs(
    x = "Infection / Dissemination Status",
    y = expression("Virus Titer (log"[10]*" GE/µL)"),
    fill = "Serotype"
  ) +
  
  theme_classic(base_size = 15) +
  theme(
    axis.title = element_text(face = "bold", size = 15),
    axis.text.x = element_text(face = "bold", color = "black", size = 12),
    axis.text.y = element_text(face = "bold", color = "black", size = 12),
    legend.position = "top",
    strip.text.x = element_text(face = "bold", size = 13),
    strip.text.y = element_text(face = "bold", size = 13),
  ) +
  annotate("segment", x= -Inf, xend = Inf, y=-Inf, yend = -Inf)+
  annotate("segment", x=-Inf, xend=-Inf, y=-Inf, yend=Inf)

# ------------------------
# Add significance brackets per strain × serotype facet
# ------------------------
for (strain in expected_strains) {
  for (sero in unique(Dataset_status$Serotype)) {
    Figure_DisseminationStatus <- Figure_DisseminationStatus +
      stat_pvalue_manual(
        data = filter(pval_df_status,
                      Mosquito_strain == strain,
                      Serotype == sero),
        label = "label",
        xmin = "group1",
        xmax = "group2",
        y.position = "y.position",
        bracket.size = 0.3,
        tip.length = 0.003,
        step.increase = 0.05
      )
  }
}

# Print
print(Figure_DisseminationStatus)