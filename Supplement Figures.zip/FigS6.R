library(readxl)
library(ggplot2)
library(ggpubr)
library(rstatix)
library(dplyr)
library(tidyr)
library(purrr)
library(tibble)
Dataset_final <- read_xlsx("~/Desktop/Extracted_data/DENV1-4_extractedPCR_Clean.xlsx", sheet = "Sheet1")

Dataset_final <- Dataset_final %>%
  mutate(
    `GE/uL_Bodies` = if_else(`Infection(<38)` == 0 & `Dissemination(<38)` == 0,
                             1,
                             as.numeric(`GE/uL_Bodies`)),
    `GE/uL_Legs` = if_else(`Infection(<38)` == 0 & `Dissemination(<38)` == 0,
                           1,
                           as.numeric(`GE/uL_Legs`))
  )

# Define colors and levels
Serotype_colors <- c("1" = "#227DCB", "2" = "#b020e0", "3" = "#ffce9d", "4" = "#954226")
expected_strains <- c("WT", "wAlbB", "wMelM")
serotype_labels <- c("1" = "DENV-1", "2" = "DENV-2", "3" = "DENV-3", "4" = "DENV-4")

# Helper function to fill missing combinations and fix factors
complete_and_fix_factors <- function(data, value_column, strains = expected_strains) {
  data %>%
    complete(Serotype, Mosquito_strain = strains) %>%
    mutate(Mosquito_strain = factor(Mosquito_strain, levels = strains)) %>%
    drop_na({{ value_column }})
}

# ---------------------------------------------------------
# NEW: Include *all* mosquitoes, not just disseminated ones
# ---------------------------------------------------------
Dataset_all_bodies <- Dataset_final %>%
  mutate(
    Serotype = factor(Serotype),
    GE_log10_Bodies = log10(pmax(as.numeric(`GE/uL_Bodies`), 0.034)),
    Mosquito_strain = if_else(Mosquito_strain == "wMel", "wMelM", Mosquito_strain),
    Mosquito_strain = factor(Mosquito_strain, levels = expected_strains)
  )

Dataset_all_bodies_complete <- complete_and_fix_factors(Dataset_all_bodies, GE_log10_Bodies)

# -----------------------
# Compute medians and CI
# -----------------------
CI_all <- Dataset_all_bodies_complete %>%
  group_by(Mosquito_strain, Serotype) %>%
  summarise(
    x4 = quantile(GE_log10_Bodies, 0.025, na.rm = TRUE),
    ratio2 = quantile(GE_log10_Bodies, 0.5, na.rm = TRUE),
    x5 = quantile(GE_log10_Bodies, 0.975, na.rm = TRUE),
    .groups = "drop"
  )

# -----------------------
# Pairwise Wilcoxon + BH adjustment
# -----------------------
my_comparisons <- list(c("WT", "wAlbB"), c("wAlbB", "wMelM"), c("WT", "wMelM"))

pval_df_all <- data.frame()
for (s in unique(Dataset_all_bodies_complete$Serotype)) {
  sub_data <- Dataset_all_bodies_complete %>% filter(Serotype == s)
  
  pairwise_result <- pairwise.wilcox.test(
    sub_data$GE_log10_Bodies,
    sub_data$Mosquito_strain,
    p.adjust.method = "BH"
  )
  
  res <- as.data.frame(as.table(pairwise_result$p.value))
  colnames(res) <- c("group1", "group2", "p.adj")
  res <- res %>%
    filter(!is.na(p.adj)) %>%
    mutate(Serotype = s)
  
  pval_df_all <- bind_rows(pval_df_all, res)
}

# Set y-position and labels for significance
pval_df_all <- pval_df_all %>%
  mutate(
    Serotype = factor(Serotype, levels = levels(Dataset_all_bodies_complete$Serotype)),
    y.position = 5.8,
    label = case_when(
      p.adj < 0.0001 ~ "***",
      p.adj < 0.01 ~ "**",
      p.adj < 0.05 ~ "*",
      TRUE ~ "ns"
    )
  )

# -----------------------
# Plot (all mosquitoes)
# -----------------------
library(ggbeeswarm)
library(ggplot2)
library(ggpubr)
library(dplyr)

Figure4A_all <- ggplot(Dataset_all_bodies_complete,
                       aes(x = Mosquito_strain,
                           y = GE_log10_Bodies,
                           fill = Serotype)) +
  
  # --- Smart beeswarm points (replaces geom_dotplot) ---
  geom_quasirandom(
    width = 0.3,            # controls horizontal spread (0.2–0.3 works well)
    varwidth = FALSE,        # consistent width per group
    groupOnX = TRUE,         # ensures spacing per strain
    dodge.width = 0.6,       # minor horizontal dodging by Serotype (optional)
    shape = 21,              # filled circle with black outline
    size = 2.5,
    stroke = 0.3,
    color = "black",
    alpha = 0.9
  ) +
  
  # --- Confidence intervals (drawn on top) ---
  geom_errorbar(
    data = CI_all,
    aes(x = Mosquito_strain, ymin = x4, ymax = x5),
    width = 0.1,
    inherit.aes = FALSE,
    color = "black",
    linewidth = 0.6,
    alpha = 0.9
  ) +
  
  # --- Medians (bold black lines) ---
  geom_crossbar(
    data = CI_all,
    aes(x = Mosquito_strain, y = ratio2, ymin = ratio2, ymax = ratio2),
    width = 0.5,
    color = "black",
    linewidth = 1.0,
    alpha = 1,
    inherit.aes = FALSE
  ) +
  
  # --- Y-axis settings ---
  scale_y_continuous(
    breaks = seq(0, 6.8, 1),
    limits = c(0, 6.8),
    expand = expansion(mult = c(0.02, 0.05))
  ) +
  
  # --- Facet by serotype ---
  facet_wrap(~ Serotype, nrow = 1,
             labeller = as_labeller(serotype_labels),
             scales = "fixed") +
  
  # --- Manual color scale ---
  scale_fill_manual(values = Serotype_colors,
                    labels = serotype_labels) +
  
  # --- Labels ---
  labs(
    x = "Mosquito Strain",
    y = expression("Virus Titer (log"[10]*" GE/µL)"),
    fill = "Serotype"
  ) +
  
  # --- Theme ---
  theme_classic(base_size = 15) +
  theme(
    axis.title = element_text(face = "bold", size = 15),
    axis.text.x = element_text(color = "black", face = "bold", size = 12),
    axis.text.y = element_text(color = "black", face = "bold", size = 12),
    legend.position = "top",
    strip.text = element_text(face = "bold", size = 14)
  )

# --- Significance brackets per serotype panel ---
for (s in unique(pval_df_all$Serotype)) {
  Figure4A_all <- Figure4A_all +
    stat_pvalue_manual(
      data = filter(pval_df_all, Serotype == s),
      label = "label",
      xmin = "group1",
      xmax = "group2",
      y.position = "y.position",
      bracket.size = 0.3,
      tip.length = 0.003,
      step.increase = 0.05
    )
}


print(Figure4A_all)