library(dplyr)
library(purrr)
Genotype_colors <- c("#F0F8FF", "#CBE6FD", "#85C7F4", "#4BAEF2", "#227DCB", "#0A4A7A","#f7e8ff", "#db99ff", "#b020e0", "#a300fb", "#4a0072", "#240037",  "#eb7600", "#ffb162", "#ffce9d", "#cd613c", "#954226", "#471f12")


dissemination_rate_per_infected <- Dataset_final %>% 
  mutate(`Infection(<38)` = as.numeric(`Infection(<38)`)) %>% 
  mutate(`Dissemination(<38)` = as.numeric(`Dissemination(<38)`)) %>% 
  group_by(Virus, Mosquito_strain, Genotype) %>% 
  summarise(percentage = sum(`Dissemination(<38)`)/sum(`Infection(<38)`),
            sample_size = n())  %>% 
  ungroup() %>% 
  mutate(Serotype = gsub("[^0-9]", "",Genotype))

dissemination_rate_per_infected$Mosquito_strain <- factor(infection_rate$Mosquito_strain, levels = c("WT", "wAlbB", "wMel"))

dissemination_rate_per_infected <- Dataset_final %>% 
  mutate(
    `Infection(<38)` = as.numeric(`Infection(<38)`),
    `Dissemination(<38)` = as.numeric(`Dissemination(<38)`)
  ) %>% 
  group_by(Virus, Mosquito_strain, Genotype) %>% 
  summarise(
    percentage = sum(`Dissemination(<38)`)/sum(`Infection(<38)`),
    sample_size = n()
  ) %>% 
  ungroup() %>%
  mutate(
    Serotype = gsub("[^0-9]", "", Genotype),
    Mosquito_strain = factor(Mosquito_strain, levels = c("WT", "wAlbB", "wMel"))
  )

f4B <- dissemination_rate_per_infected %>%
  mutate(
    Virus = ifelse(Virus == "DH069A", "DH069", Virus),
    Genotype = factor(Genotype, levels = genotype_order)
  ) %>%
  arrange(Genotype) %>%
  ggplot(aes(
    x = factor(Virus, levels = rev(unique(Virus))),
    y = percentage * 100,
    fill = Genotype
  )) +
  geom_bar(stat = "identity", color = "black", size = 0.05) + 
  coord_flip() +
  scale_fill_manual(values = Genotype_colors) +
  scale_fill_manual(values = c("1I" =  Genotype_colors[1],
                               "1II" =  Genotype_colors[2],
                               "1III" = Genotype_colors[3],
                               "1IV" =  Genotype_colors[4],
                               "1V" = Genotype_colors[5],
                               "1VII" =  Genotype_colors[6],
                               "2I" = Genotype_colors[7],
                               "2II" =  Genotype_colors[8],
                               "2III" =   Genotype_colors[9],
                               "2IV" =  Genotype_colors[10],
                               "2V" =  Genotype_colors[11],
                               "2VI" =  Genotype_colors[12],
                               "3I" =  Genotype_colors[13],
                               "3II" =  Genotype_colors[14],
                               "3III" =  Genotype_colors[15],
                               "4I" =  Genotype_colors[16],
                               "4II" = Genotype_colors[17],
                               "4IV" =  Genotype_colors[18]))+
  facet_grid(Serotype ~ Mosquito_strain, scales = "free_y", space = "free_y", 
             labeller = labeller(Mosquito_strain = c("wMel" = "wMelM"))) + 
  theme_classic() +
  ylab("Dissemination (%)") + xlab("Virus") +
  theme(
    panel.border = element_blank(),
    axis.line = element_line(colour = "black"),
    plot.title = element_text(face = "bold", hjust = 0.5),
    axis.text.x = element_text(color = "black", size = 12),
    axis.text.y = element_text(color = "black", size = 12),
    text = element_text(size = 12)
  )

f4B