library(tidyverse)
library(ggpubr)
library(xtable)
library(stargazer)
library(broom)
library(minpack.lm)
library(readxl)

Dataset_final <-  readxl::read_xlsx("DENV1-4_extractedPCR_Clean.xlsx", sheet = "Sheet1")


############################. Figure 3A. ######################################


Serotype_colors <- c("#227DCB", "#b020e0", "#ffce9d","#954226")
Genotype_colors <- c("#F0F8FF", "#CBE6FD", "#85C7F4", "#4BAEF2", "#227DCB", "#0A4A7A","#f7e8ff", "#db99ff", "#b020e0", "#a300fb", "#4a0072", "#240037",  "#eb7600", "#ffb162", "#ffce9d", "#cd613c", "#954226", "#471f12")


dissemination_rate <- Dataset_final %>% 
  mutate(`Infection(<38)` = as.numeric(`Infection(<38)`)) %>% 
  mutate(`Dissemination(<38)` = as.numeric(`Dissemination(<38)`)) %>% 
  group_by(Virus, Mosquito_strain, Serotype) %>% 
  summarise(percentage = sum(`Dissemination(<38)`)/n(),
            sample_size = n())  %>% 
  ungroup() 


dissemination_rate_WT <- dissemination_rate %>% filter(Mosquito_strain == "WT")
dissemination_rate_wAlbB <- dissemination_rate %>% filter(Mosquito_strain == "wAlbB")
dissemination_rate_wMel <- dissemination_rate %>% filter(Mosquito_strain == "wMel")


combined_dissemination_rate_WT_wAlbB <- merge(dissemination_rate_WT, 
                                              dissemination_rate_wAlbB,
                                              by = c("Virus", "Serotype")) %>% 
  mutate(ratio = percentage.y / percentage.x) %>% 
  filter(!is.na(ratio)) %>% 
  filter(is.finite(ratio))


combined_dissemination_rate_WT_wMel  <- merge(dissemination_rate_WT, 
                                              dissemination_rate_wMel,
                                              by = c("Virus", "Serotype")) %>% 
  mutate(ratio = percentage.y / percentage.x) %>% 
  filter(!is.na(ratio)) %>% 
  filter(is.finite(ratio))


dissemination_rate_wAlbB_wMel <- data.frame(ratio = c(combined_dissemination_rate_WT_wAlbB$ratio, combined_dissemination_rate_WT_wMel$ratio),
                                            type = rep(c("wAlbB", "wMel"), c(length(combined_dissemination_rate_WT_wAlbB$Virus), length(combined_dissemination_rate_WT_wMel$Virus))),
                                            Serotype = c(combined_dissemination_rate_WT_wAlbB$Serotype,combined_dissemination_rate_WT_wMel$Serotype ))


CI_95 <- dissemination_rate_wAlbB_wMel %>%  
  rename(ratio1 = "ratio", type = "type", Serotype = "Serotype") %>% 
  group_by(type) %>% 
  summarise(x1 = quantile(ratio1, 0.025),
            ratio = quantile(ratio1, 0.5), 
            x3 = quantile(ratio1, 0.975))


Figure3A <- dissemination_rate_wAlbB_wMel %>% 
  mutate(Serotype = factor(Serotype)) %>% 
  ggplot(aes(x = type, y = ratio)) + 
  geom_dotplot(aes(color = Serotype, fill = Serotype), binaxis='y', stackdir='center',
               stackratio=.8, dotsize= .5, binwidth =  1/20, alpha = 1, color = "black") +
  geom_crossbar(data = CI_95, aes(x = type, y = ratio, ymin = ratio, ymax = ratio), 
                width = 0.35, color = "black", linewidth = 0.3, alpha = 0.5) +
  geom_errorbar(data = CI_95, aes(x = type, ymin = x1, ymax = x3),
                width = .1, color = "black") +
  #geom_boxplot(color = "black", fill = NA, outlier.colour = "NA", width = .1, alpha = .5) + 
  geom_hline(aes(yintercept = 1), color = "black", linetype = "dashed") +
  theme_classic() +
  scale_fill_manual(values = c("1" =  Serotype_colors[1],
                               "2" =  Serotype_colors[2],
                               "3" = Serotype_colors[3],
                               "4" =  Serotype_colors[4])) +
  scale_color_manual(values = c("1" =  Serotype_colors[1],
                                "2" =  Serotype_colors[2],
                                "3" = Serotype_colors[3],
                                "4" =  Serotype_colors[4])) +
  scale_x_discrete(labels = c("wAlbB" = "wAlbB", "wMel" = "wMelM")) +
  theme(legend.key = element_rect(fill = "white", colour = "white"), legend.position = "top") +
  theme(panel.border = element_blank(), axis.line = element_line(colour = "black")) +
  theme(panel.grid.minor  = element_blank(), 
        axis.line = element_line(colour = "black")) + 
  labs(
    #title = "Viral copies by Vaccination Status",
    y = "Dissemination rate normalized to Wildtype",
    x = "Mosquito Strain") +
  theme(axis.text.x = element_text(color="black",
                                   size=20, angle=0),
        axis.text.y = element_text(color="black",
                                   size=20, angle=0),
        text = element_text(size = 20))  +
  theme(plot.title = element_text(hjust = 0.5)) + 
  theme(
    axis.text.x = element_text(face="bold"),
    axis.text.y = element_text(face="bold"),
    axis.title.x = element_text(face="bold"),
    axis.title.y = element_text(face="bold"),
    axis.line.x = element_line(color="black", linewidth = 1),
    axis.line.y = element_line(color="black", linewidth = 1),
    plot.title = element_text(face="bold", hjust = 0.5)
  ) 
symnum.args <- list(cutpoints = c(0, 0.0001, 0.01, 0.05, 1), symbols = c( "***", "**", "*", "ns"))

Figure3A  = Figure3A + stat_compare_means(
  comparisons = list(c("wAlbB", "wMel")),
  method = "wilcox.test", # Choose the appropriate statistical test
  label = "p.signif",
  size = 5,
  tip.length = 0.005,
  symnum.args = symnum.args,
  step.increase = 0.06,
  bracket.size = 0.5
)
Figure3A  


############################. Figure 3B. ######################################
 
dissemination_rate <- Dataset_final %>% 
  mutate(`Infection(<38)` = as.numeric(`Infection(<38)`)) %>% 
  #filter(`Infection(<38)` == 1) %>% 
  mutate(`Dissemination(<38)` = as.numeric(`Dissemination(<38)`)) %>% 
  group_by(Virus, Mosquito_strain, Serotype, Genotype) %>% 
  summarise(percentage = sum(`Dissemination(<38)`)/n(),
            sample_size = n())  %>% 
  ungroup() %>% 
  mutate(Serotype = gsub("[^0-9]", "",Genotype))


dissemination_rate_WT <- dissemination_rate %>% filter(Mosquito_strain == "WT")
dissemination_rate_wAlbB <- dissemination_rate %>% filter(Mosquito_strain == "wAlbB")
dissemination_rate_wMel <- dissemination_rate %>% filter(Mosquito_strain == "wMel")



combined_dissemination_rate_WT_wAlbB <- merge(dissemination_rate_WT, 
                                              dissemination_rate_wAlbB,
                                              by = c("Virus", "Serotype", "Genotype")) %>% 
  mutate(ratio = percentage.y / percentage.x) %>% 
  filter(!is.na(ratio)) %>% 
  filter(is.finite(ratio))


combined_dissemination_rate_WT_wMel  <- merge(dissemination_rate_WT, 
                                              dissemination_rate_wMel,
                                              by = c("Virus", "Serotype", "Genotype")) %>% 
  mutate(ratio = percentage.y / percentage.x) %>% 
  filter(!is.na(ratio)) %>% 
  filter(is.finite(ratio))


dissemination_rate_wAlbB_wMel <- data.frame(ratio = c(combined_dissemination_rate_WT_wAlbB$ratio, combined_dissemination_rate_WT_wMel$ratio),
                                            type = rep(c("wAlbB", "wMel"),  c(length(combined_dissemination_rate_WT_wAlbB$Virus), length(combined_dissemination_rate_WT_wMel$Virus))),
                                            Serotype = c(combined_dissemination_rate_WT_wAlbB$Serotype, combined_dissemination_rate_WT_wMel$Serotype),
                                            Genotype = c(combined_dissemination_rate_WT_wAlbB$Genotype, combined_dissemination_rate_WT_wMel$Genotype))


CI_95 <- dissemination_rate_wAlbB_wMel %>%  
  rename(ratio1 = "ratio", type = "type", Serotype = "Serotype", Genotype = "Genotype") %>% 
  group_by(Serotype) %>% 
  summarise(x1 = quantile(ratio1, 0.025),
            ratio = quantile(ratio1, 0.5), 
            x3 = quantile(ratio1, 0.975))




Figure3B <- dissemination_rate_wAlbB_wMel %>% 
  mutate(Serotype = factor(Serotype)) %>% 
  ggplot(aes(x = Serotype, y = ratio)) + 
  geom_dotplot(aes(color = Genotype, fill = Genotype), binaxis='y', stackdir='center',
               stackratio=.8, dotsize= .8, binwidth =  1/20, alpha = 1, color = "black") + 
  geom_crossbar(data = CI_95, aes(x = Serotype, y = ratio, ymin = ratio, ymax = ratio),
                width =0.6, color = "black", linewidth =0.4, alpha = 0.5) +
  #geom_point(data = CI_95, aes(x = Serotype, y = ratio), size = 4, fill = "black", shape = 23) +
  geom_errorbar(data = CI_95, aes(x = Serotype, ymin = x1, ymax = x3),
                width = .1, color = "black") +
  #geom_boxplot(color = "black", fill = NA, outlier.colour = "NA", width = .1, alpha = .5) + 
  geom_hline(aes(yintercept = 1), color = "black", linetype = "dashed") +
  theme_classic() +
  theme(legend.key = element_rect(fill = "white", colour = "white"), legend.position = "right") +
  theme(panel.border = element_blank(), axis.line = element_line(colour = "black")) +
  theme(panel.grid.minor  = element_blank(), 
        axis.line = element_line(colour = "black")) + 
  labs(
    #title = "Serotype",
    y = "Dissemination rate normalized to Wildtype",
    x = "Serotype") +
  theme(axis.text.x = element_text(color="black",
                                   size=20, angle=0),
        axis.text.y = element_text(color="black",
                                   size=20, angle=0),
        text = element_text(size = 20))  +
  theme(plot.title = element_text(hjust = 0.5)) + 
  theme(
    axis.text.x = element_text(face="bold"),
    axis.text.y = element_text(face="bold"),
    axis.title.x = element_text(face="bold"),
    axis.title.y = element_text(face="bold"),
    axis.line.x = element_line(color="black", linewidth = 1),
    axis.line.y = element_line(color="black", linewidth = 1),
    plot.title = element_text(face="bold", hjust = 0.5)
  ) + 
  facet_wrap(~type, labeller = as_labeller(c("wMel" = "wMelM", "wAlbB" = "wAlbB"))) + 
  theme(strip.text = element_text(face ="bold", size = 20)) + 
  scale_fill_manual(values = c("1I" =  Genotype_colors[1],
                               "1II" =  Genotype_colors[2],
                               "1III" = Genotype_colors[3],
                               "1IV" =  Genotype_colors[4],
                               "1V" = Genotype_colors[5],
                               "1VI" =  Genotype_colors[6],
                               "2I" = Genotype_colors[7],
                               "2II" =  Genotype_colors[8],
                               "2III" =   Genotype_colors[9],
                               "2IV" =  Genotype_colors[10],
                               "2V" =  Genotype_colors[11],
                               "2VI" =  Genotype_colors[12],
                               "3I" =  Genotype_colors[13],
                               "3II" =  Genotype_colors[14],
                               "3III" =  Genotype_colors[15],
                               "4I" =  Genotype_colors[16],
                               "4II" = Genotype_colors[17],
                               "4IV" =  Genotype_colors[18])) +
  scale_color_manual(values = c("1I" =  Genotype_colors[1],
                                "1II" =  Genotype_colors[2],
                                "1III" = Genotype_colors[3],
                                "1IV" =  Genotype_colors[4],
                                "1V" = Genotype_colors[5],
                                "1VI" =  Genotype_colors[6],
                                "2I" = Genotype_colors[7],
                                "2II" =  Genotype_colors[8],
                                "2III" =   Genotype_colors[9],
                                "2IV" =  Genotype_colors[10],
                                "2V" =  Genotype_colors[11],
                                "2VI" =  Genotype_colors[12],
                                "3I" =  Genotype_colors[13],
                                "3II" =  Genotype_colors[14],
                                "3III" =  Genotype_colors[15],
                                "4I" =  Genotype_colors[16],
                                "4II" = Genotype_colors[17],
                                "4IV" =  Genotype_colors[18])) 


symnum.args <- list(cutpoints = c(0, 0.0001, 0.01, 0.05, 1), symbols = c( "***", "**", "*", "ns"))



# Define comparisons
comparisons <- list(c("1", "2"), c("1", "3"), c("1", "4"),
                    c("2", "3"), c("2", "4"), c("3", "4"))

# Y-positions to avoid overlap
y_positions_base <- seq(1.1, 1.2, length.out = length(comparisons))

# Initialize empty list for results
all_pvals <- list()

# Loop over each Wolbachia type
for (s in unique(dissemination_rate_wAlbB_wMel$type)) {
  df_sub <- dissemination_rate_wAlbB_wMel %>% filter(type == s)
  
  raw_pvals <- numeric(length(comparisons))
  
  for (i in seq_along(comparisons)) {
    groups <- comparisons[[i]]
    comp_data <- df_sub %>% filter(Serotype %in% groups)
    raw_pvals[i] <- wilcox.test(ratio ~ Serotype, data = comp_data)$p.value
  }
  
  adj_pvals <- p.adjust(raw_pvals, method = "BH")
  
  pval_df_s <- do.call(rbind, lapply(seq_along(comparisons), function(i) {
    data.frame(
      group1 = comparisons[[i]][1],
      group2 = comparisons[[i]][2],
      y.position = y_positions_base[i],
      p.adj = adj_pvals[i],
      label = symnum(adj_pvals[i], corr = FALSE, na = FALSE,
                     cutpoints = c(0, 0.0001, 0.01, 0.05, 1),
                     symbols = c("***", "**", "*", "ns")),
      type = s
    )
  }))
  
  all_pvals[[s]] <- pval_df_s
}

# Combine into single data frame
pval_df <- bind_rows(all_pvals)

# Add adjusted p-value brackets for each facet
for (s in unique(pval_df$type)) {
  Figure3B <- Figure3B +
    stat_pvalue_manual(
      data = filter(pval_df, type == s),
      label = "label",
      xmin = "group1",
      xmax = "group2",
      y.position = "y.position",
      bracket.size = 0.5,
      tip.length = 0.005,
      step.increase = 0.06
    )
}

print(Figure3B)

# Figure3B  = Figure3B + stat_compare_means(
#   comparisons = list(c("1", "2"), 
#                      c("1", "3"), 
#                      c("1", "4"), 
#                      c("2", "3"), 
#                      c("2", "4"), 
#                      c("3", "4")),
#   method = "wilcox.test", # Choose the appropriate statistical test
#   label = "p.signif",
#   size = 5,
#   tip.length = 0.005,
#   symnum.args = symnum.args,
#   step.increase = 0.06,
#   bracket.size = 0.5
# )
# 
# 
# Figure3B


############################. Figure 3C. ######################################


Figure3C <- dissemination_rate_wAlbB_wMel %>% 
  mutate(Serotype = factor(Serotype)) %>% 
  ggplot(aes(x = Genotype, y = ratio, color = Genotype, fill = Genotype)) + 
  geom_dotplot(binaxis='y', stackdir='center', color = "black", 
               stackratio=.8, dotsize= 0.5, binwidth =  1/20, alpha = 1) + 
  # geom_boxplot(color = "black", fill = NA, outlier.colour = "NA", width = .1, alpha = .5) + 
  geom_hline(aes(yintercept = 1), color = "black", linetype = "dashed") +
  theme_classic() +
  theme(legend.key = element_rect(fill = "white", colour = "white"), legend.position = "NA") +
  theme(panel.border = element_blank(), axis.line = element_line(colour = "black")) +
  theme(panel.grid.minor  = element_blank(), 
        axis.line = element_line(colour = "black")) + 
  labs(
    #title = "Serotype",
    y = "Dissemination rate normalized to Wildtype",
    x = "Genotype") +
  theme(axis.text.x = element_text(color="black",
                                   size=20, angle=0),
        axis.text.y = element_text(color="black",
                                   size=20, angle=0),
        text = element_text(size = 20))  +
  theme(plot.title = element_text(hjust = 0.5)) + 
  theme(
    axis.text.x = element_text(face="bold"),
    axis.text.y = element_text(face="bold"),
    axis.title.x = element_text(face="bold"),
    axis.title.y = element_text(face="bold"),
    axis.line.x = element_line(color="black", linewidth = 1),
    axis.line.y = element_line(color="black", linewidth = 1),
    plot.title = element_text(face="bold", hjust = 0.5)
  ) + 
  facet_wrap(~type, labeller = as_labeller(c("wMel" = "wMelM", "wAlbB" = "wAlbB"))) + 
  theme(strip.text = element_text(face ="bold", size = 20)) +
  scale_fill_manual(values = c("1I" =  Genotype_colors[1],
                               "1II" =  Genotype_colors[2],
                               "1III" = Genotype_colors[3],
                               "1IV" =  Genotype_colors[4],
                               "1V" = Genotype_colors[5],
                               "1VI" =  Genotype_colors[6],
                               "2I" = Genotype_colors[7],
                               "2II" =  Genotype_colors[8],
                               "2III" =   Genotype_colors[9],
                               "2IV" =  Genotype_colors[10],
                               "2V" =  Genotype_colors[11],
                               "2VI" =  Genotype_colors[12],
                               "3I" =  Genotype_colors[13],
                               "3II" =  Genotype_colors[14],
                               "3III" =  Genotype_colors[15],
                               "4I" =  Genotype_colors[16],
                               "4II" = Genotype_colors[17],
                               "4IV" =  Genotype_colors[18])) +
  scale_color_manual(values = c("1I" =  Genotype_colors[1],
                                "1II" =  Genotype_colors[2],
                                "1III" = Genotype_colors[3],
                                "1IV" =  Genotype_colors[4],
                                "1V" = Genotype_colors[5],
                                "1VI" =  Genotype_colors[6],
                                "2I" = Genotype_colors[7],
                                "2II" =  Genotype_colors[8],
                                "2III" =   Genotype_colors[9],
                                "2IV" =  Genotype_colors[10],
                                "2V" =  Genotype_colors[11],
                                "2VI" =  Genotype_colors[12],
                                "3I" =  Genotype_colors[13],
                                "3II" =  Genotype_colors[14],
                                "3III" =  Genotype_colors[15],
                                "4I" =  Genotype_colors[16],
                                "4II" = Genotype_colors[17],
                                "4IV" =  Genotype_colors[18])) 
Figure3C


############################. Figure 3D. ######################################


CT_stock <- Dataset_final %>% 
  select(Virus, `GE/uL_stock`, Serotype,Genotype) %>% 
  unique()



infection_rate <- Dataset_final %>% 
  mutate(`Infection(<38)` = as.numeric(`Infection(<38)`)) %>% 
  group_by(Virus, Mosquito_strain, Genotype) %>% 
  summarise(percentage = sum(`Infection(<38)`)/n(), 
            sample_size = n())  %>% 
  ungroup() %>% 
  mutate(Serotype = gsub("[^0-9]", "",Genotype))


dissemination_rate <- Dataset_final %>% 
  mutate(`Infection(<38)` = as.numeric(`Infection(<38)`)) %>% 
  mutate(`Dissemination(<38)` = as.numeric(`Dissemination(<38)`)) %>% 
  group_by(Virus, Mosquito_strain, Genotype) %>% 
  summarise(percentage = sum(`Dissemination(<38)`)/n(),
            sample_size = n())  %>% 
  ungroup() %>% 
  mutate(Serotype = gsub("[^0-9]", "",Genotype))




infection_rate$Mosquito_strain <- factor(infection_rate$Mosquito_strain, levels = c("WT", "wAlbB", "wMel"))


Serotype_colors <- c("#227DCB", "#b020e0", "#ffce9d","#954226")
Genotype_colors <- c("#F0F8FF", "#CBE6FD", "#85C7F4", "#4BAEF2", "#227DCB", "#0A4A7A","#f7e8ff", "#db99ff", "#b020e0", "#a300fb", "#4a0072", "#240037",  "#eb7600", "#ffb162", "#ffce9d", "#cd613c", "#954226", "#471f12")




######## pooled analysis: considering all serotype and all mosquito types together ##########

# calculate infection rate for all mosquito by short_body_id



combined_infection_rate_stock <- merge(infection_rate, 
                                       CT_stock,
                                       by.x = "Virus", 
                                       by.y = "Virus")


combined_dissemination_rate_stock <- merge(dissemination_rate, 
                                           CT_stock,
                                           by.x = "Virus", 
                                           by.y = "Virus")

 

 

combined_infection_rate_stock <- merge(infection_rate, 
                                       CT_stock,
                                       by = c("Virus", "Serotype"))



combined_dissemination_rate_stock <- merge(dissemination_rate, 
                                           CT_stock,
                                           by = c("Virus", "Serotype"))


# Combined infection rate plot with linear regression lines for each mosquito strain within serotype facets

# Create a named vector for renaming the facets
serotype_labels <- c("1" = "DENV-1", "2" = "DENV-2", "3" = "DENV-3", "4" = "DENV-4")

# Define custom colors for mosquito strains
mosquito_strain_colors <- c("WT" = "#33b89a",  
                            "wMel" = "#3b5323", 
                            "wAlbB" = "#b8cc00"
)
 


 

cor_df <- combined_infection_rate_stock %>%
  group_by(Serotype, Mosquito_strain) %>%
  summarise(
    cor_test = list(cor.test(log10(`GE/uL_stock`), percentage * 100)),
    .groups = "drop"
  ) %>%
  mutate(
    r = sapply(cor_test, function(x) round(x$estimate, 2)),
    p = sapply(cor_test, function(x) x$p.value),
    stars = case_when(
      p < 0.0001 ~ "***",
      p < 0.01 ~ "**",
      p < 0.05 ~ "*",
      TRUE ~ "ns"
    ),
    label = paste0('r = ', r, '(', stars, ')'),
    x = 2.5,
    y = case_when(
      Mosquito_strain == "WT" ~ 105,
      Mosquito_strain == "wAlbB" ~ 95,
      Mosquito_strain == "wMel" ~ 85
    )
  )
 

combined_infection_rate_stock %>% 
  group_by(Serotype) %>% 
  summarise(corr_coeff = cor(log10(`GE/uL_stock`), percentage))




# Combined dissemination rate plot with linear regression lines for each mosquito strain within serotype facets
# Define custom colors for mosquito strains
mosquito_strain_colors <- c("WT" = "#33b89a",  
                            "wMel" = "#3b5323", 
                            "wAlbB" = "#b8cc00"
)


cor_df <- combined_dissemination_rate_stock %>%
  group_by(Serotype, Mosquito_strain) %>%
  summarise(
    cor_test = list(cor.test(log10(`GE/uL_stock`), percentage * 100)),
    .groups = "drop"
  ) %>%
  mutate(
    r = sapply(cor_test, function(x) round(x$estimate, 2)),
    p = sapply(cor_test, function(x) x$p.value),
    stars = case_when(
      p < 0.0001 ~ "***",
      p < 0.01 ~ "**",
      p < 0.05 ~ "*",
      TRUE ~ "ns"
    ),
    label = paste0('r = ', r, '(', stars, ')'),
    x = 2.5,
    y = case_when(
      Mosquito_strain == "WT" ~ 105,
      Mosquito_strain == "wAlbB" ~ 95,
      Mosquito_strain == "wMel" ~ 85
    )
  )


# Combined dissemination rate plot with linear regression lines for each mosquito strain within serotype facets
Figure3D <- combined_dissemination_rate_stock %>%
  ggplot(aes(x = log10(`GE/uL_stock`), y = percentage * 100)) + 
  theme_classic() +
  geom_point(aes(fill = Mosquito_strain), color = "black", size = 3.5, shape = 21) +  # Filling points with strain color and black outline
  geom_smooth(aes(color = Mosquito_strain), method = "lm", linetype = "solid", se = FALSE) +  # Adding linear regression lines
  geom_text(
    data = cor_df,
    aes(x = x, y = y, label = label, color = Mosquito_strain),
    inherit.aes = FALSE,
    size = 6,
    fontface = "bold",
    show.legend = FALSE
  ) +
  facet_wrap(~ Serotype, nrow = 1, labeller = as_labeller(serotype_labels)) + 
  ylab("Dissemination rate") + 
  xlab("Stock viral copies (log10)") + 
  scale_fill_manual(values = mosquito_strain_colors, limits = c("WT", "wAlbB", "wMel"), labels = c("WT", "wAlbB", "wMelM")) +  # Customize fill colors for each mosquito strain
  scale_color_manual(values = mosquito_strain_colors, limits = c("WT", "wAlbB", "wMel"), labels = c("WT", "wAlbB", "wMelM")) + # Customize colors for the smoothed lines
  scale_y_continuous(breaks = c(0, 25, 50, 75, 100)) +
  guides(fill = guide_legend(title = "Mosquito Strain"), color = guide_legend(title = "Mosquito Strain")) +
  theme(
    legend.position = "top",
    legend.text = element_text(color = "black", size = 20, face="bold"),
    legend.title = element_text(color = "black", size = 20, face="bold"),
    strip.text = element_text(color = "black", size = 20, face="bold"),
    axis.text.x = element_text(color = "black", size = 20, face="bold"),
    axis.text.y = element_text(color = "black", size = 20, face="bold"),
    axis.title.x = element_text(color = "black", size = 20, face="bold"),
    axis.title.y = element_text(color = "black", size = 20, face="bold"),
    axis.line.x = element_line(color="black", linewidth = 1),
    axis.line.y = element_line(color="black", linewidth = 1),
    plot.title = element_text(size = 20, face="bold", hjust = 0.5)
  )

Figure3D
