# Load libraries
library(readxl)
library(ggplot2)
library(ggpubr)
library(rstatix)
library(dplyr)
library(tidyr)
library(purrr)
library(tibble)

Dataset_final <- read_xlsx("DENV1-4_extractedPCR_Clean.xlsx", sheet = "Sheet1")

# Define colors and levels
Serotype_colors <- c("1" = "#227DCB", "2" = "#b020e0", "3" = "#ffce9d", "4" = "#954226")
expected_strains <- c("WT", "wAlbB", "wMelM")
serotype_labels <- c("1" = "DENV-1", "2" = "DENV-2", "3" = "DENV-3", "4" = "DENV-4")

# Complete and factor helper
complete_and_fix_factors <- function(data, value_column, strains = expected_strains) {
  data %>%
    complete(Serotype, Mosquito_strain = strains) %>%
    mutate(Mosquito_strain = factor(Mosquito_strain, levels = strains)) %>%
    drop_na({{ value_column }})
}

# Preprocess data
Dataset_disseminated_bodies <- Dataset_final %>%
  filter(`Dissemination(<38)` == 1) %>%
  mutate(
    Serotype = factor(Serotype),
    GE_log10_Bodies = log10(as.numeric(`GE/uL_Bodies`)),
    Mosquito_strain = if_else(Mosquito_strain == "wMel", "wMelM", Mosquito_strain),
    Mosquito_strain = factor(Mosquito_strain, levels = expected_strains)
  )

Dataset_disseminated_bodies_complete <- complete_and_fix_factors(Dataset_disseminated_bodies, GE_log10_Bodies)

# -----------------------
# Compute medians and CI
# -----------------------

CI_disseminated <- Dataset_disseminated_bodies_complete %>%
  group_by(Mosquito_strain, Serotype) %>%
  summarise(
    x4 = quantile(GE_log10_Bodies, 0.025, na.rm = TRUE),
    ratio2 = quantile(GE_log10_Bodies, 0.5),
    x5 = quantile(GE_log10_Bodies, 0.975, na.rm = TRUE),
    .groups = "drop"
  )

# -----------------------
# Adjusted p-value computation (Wilcoxon + BH)
# -----------------------

my_comparisons <- list(c("WT", "wAlbB"), c("wAlbB", "wMelM"), c("WT", "wMelM"))

# Collect adjusted p-values
pval_df <- data.frame()
for (s in unique(Dataset_disseminated_bodies_complete$Serotype)) {
  sub_data <- Dataset_disseminated_bodies_complete %>% filter(Serotype == s)
  
  pairwise_result <- pairwise.wilcox.test(
    sub_data$GE_log10_Bodies,
    sub_data$Mosquito_strain,
    p.adjust.method = "BH"
  )
  
  res <- as.data.frame(as.table(pairwise_result$p.value))
  colnames(res) <- c("group1", "group2", "p.adj")
  res <- res %>%
    filter(!is.na(p.adj)) %>%
    mutate(
      Serotype = s
    )
  
  pval_df <- bind_rows(pval_df, res)
}

# Set all y-positions to be the same across panels (e.g., y = 6.8)
pval_df <- pval_df %>%
  mutate(
    Serotype = factor(Serotype, levels = levels(Dataset_disseminated_bodies_complete$Serotype)),
    y.position = 5.8,
    label = case_when(
      p.adj < 0.0001 ~ "***",
      p.adj < 0.01 ~ "**",
      p.adj < 0.05 ~ "*",
      TRUE ~ "ns"
    )
  )



Figure4A <- ggplot(Dataset_disseminated_bodies_complete, aes(x = Mosquito_strain, y = GE_log10_Bodies, fill = Serotype)) +
  geom_dotplot(binaxis = "y", stackdir = "center", stackratio = 0.8, dotsize = 3, binwidth = 1/20, color = "black") +
  geom_errorbar(data = CI_disseminated, aes(x = Mosquito_strain, ymin = x4, ymax = x5), width = 0.1, inherit.aes = FALSE) +
  geom_crossbar(data = CI_disseminated,
                aes(x = Mosquito_strain, y = ratio2, ymin = ratio2, ymax = ratio2),
                width = 0.5, color = "black", linewidth = 0.35, alpha = 0.5, inherit.aes = FALSE) +
  scale_y_continuous(breaks = seq(0, 7, 1), limits = c(0, 6.8)) +
  facet_wrap(~ Serotype, nrow = 1, labeller = as_labeller(serotype_labels), scales = "fixed") +
  facet_wrap(~ Serotype, nrow = 1, labeller = as_labeller(serotype_labels), scales = "fixed") +
  scale_fill_manual(
    values = Serotype_colors,
    labels = serotype_labels
  ) +
  labs(x = "Mosquito Strain", y = expression("Virus Titer (log"[10]*" GE/µL)")) +
  theme_classic(base_size = 15) +
  theme(
    axis.title = element_text(face = "bold", size = 15),
    axis.text.x = element_text(color = "black", face = "bold", size = 12),
    axis.text.y = element_text(color = "black", face = "bold", size = 12),
    legend.position = "top"
  )

# Loop over serotypes and add p-value brackets per panel
for (s in unique(pval_df$Serotype)) {
  Figure4A <- Figure4A +
    stat_pvalue_manual(
      data = filter(pval_df, Serotype == s),
      label = "label",
      xmin = "group1",
      xmax = "group2",
      y.position = "y.position",
      bracket.size = 0.4,
      tip.length = 0.005,
      step.increase = 0.05
    )
}

print(Figure4A)






############################. Figure 4B / Figure 4C. ######################################

# 1) Load libraries
library(readxl)
library(ggplot2)
library(dplyr)
library(ggpubr)
library(patchwork)
library(rlang)

# 2) Read data
#setwd("~/Desktop/Extracted_data")
df <- read_excel("Wolbachia_Density_Data.xlsx")

# Debug: Check data load
print("Data loaded:")
print(head(df))

# 3) Define Serotype color palette
Serotype_colors <- c("#227DCB", "#b020e0", "#ffce9d","#954226")

# 4) Recode and factor variables
df <- df %>%
  mutate(
    Wolbachia_Type = factor(recode(Wolbachia_Type, "wMel" = "wMelM", "wAlbB" = "wAlbB")),
    Status = factor(recode(Status, "Disseminated" = "Diss.", "Undisseminated" = "Un-Diss.", "Uninfected" = "Un-Inf.")),
    Batch = factor(Batch),
    Serotype = factor(Serotype)
  )

# Debug: Check recoded factors
print("Recoded and factored data:")
print(str(df))

# 5) Split data by Wolbachia type
df_wMelM <- filter(df, Wolbachia_Type == "wMelM")
df_wAlbB <- filter(df, Wolbachia_Type == "wAlbB")

# 6) Function to compute 95% CI and median
calculate_ci <- function(data, group_var) {
  grp <- as_name(group_var)
  data %>%
    group_by(!!group_var) %>%
    summarise(
      !!grp := first(!!group_var),
      x1 = quantile(Density, 0.025, na.rm = TRUE),
      ratio = quantile(Density, 0.5, na.rm = TRUE),
      x3 = quantile(Density, 0.975, na.rm = TRUE),
      .groups = "drop"
    )
}

# 7) Prepare CI data for each plot
CI_status_wMelM   <- calculate_ci(df_wMelM,   quo(Status))
CI_serotype_wMelM <- calculate_ci(df_wMelM,   quo(Serotype))
CI_status_wAlbB   <- calculate_ci(df_wAlbB,   quo(Status))
CI_serotype_wAlbB <- calculate_ci(df_wAlbB,   quo(Serotype))

# Debug: Check CI data
print("CI status wMelM:")
print(head(CI_status_wMelM))
print("CI serotype wMelM:")
print(head(CI_serotype_wMelM))

# 8) Define comparisons for Status (still using stat_compare_means)
status_comparisons <- list(
  c("Diss.", "Un-Diss."),
  c("Diss.", "Un-Inf."),
  c("Un-Inf.","Un-Diss.")
)

# # 9) Function to generate bracket data with Wilcoxon p-values
# get_brackets <- function(data, group_var, comparisons, y_positions) {
#   results <- lapply(seq_along(comparisons), function(i) {
#     groups <- comparisons[[i]]
#     test_data <- data %>% filter(!!sym(group_var) %in% groups)
#     p_val <- wilcox.test(Density ~ get(group_var), data = test_data, p.adjust.method = "BH")$p.value
#     symbol <- symnum(p_val, corr = FALSE, na = FALSE,
#                      cutpoints = c(0, 1e-4, 0.01, 0.05, 1),
#                      symbols = c("***", "**", "*", "ns"))
#     data.frame(
#       group1 = groups[1],
#       group2 = groups[2],
#       y.position = y_positions[i],
#       label = symbol
#     )
#   })
#   do.call(rbind, results)
# }


get_brackets <- function(data, group_var, comparisons, y_positions) {
  raw_pvals <- numeric(length(comparisons))
  
  # Step 1: compute raw p-values
  for (i in seq_along(comparisons)) {
    groups <- comparisons[[i]]
    test_data <- data %>% filter(!!sym(group_var) %in% groups)
    test_data[[group_var]] <- droplevels(test_data[[group_var]])
    raw_pvals[i] <- wilcox.test(Density ~ get(group_var), data = test_data)$p.value
  }
  
  # Step 2: adjust p-values
  adj_pvals <- p.adjust(raw_pvals, method = "BH")
  
  # Step 3: generate bracket info with significance symbols
  results <- lapply(seq_along(comparisons), function(i) {
    symbol <- symnum(adj_pvals[i], corr = FALSE, na = FALSE,
                     cutpoints = c(0, 1e-4, 0.01, 0.05, 1),
                     symbols = c("***", "**", "*", "ns"))
    data.frame(
      group1 = comparisons[[i]][1],
      group2 = comparisons[[i]][2],
      y.position = y_positions[i],
      label = symbol
    )
  })
  
  do.call(rbind, results)
}

# 10) Define Serotype comparisons and bracket heights
serotype_comparisons <- list(
  c("1","2"), c("2","3"), c("3","4"), c("1","3"), c("2","4"), c("1","4")
)
serotype_y_positions <- c(3.4, 3.4, 3.4, 3.56, 3.72, 3.88)  # aligned heights for 1-2, 2-3, 3-4
status_y_positions <- c(3.4, 3.6, 3.4)

# 11) Generate bracket data for each Wolbachia type
brackets_sero_wAlbB <- get_brackets(df_wAlbB, "Serotype", serotype_comparisons, serotype_y_positions)
brackets_status_wAlbB <- get_brackets(df_wAlbB, "Status", status_comparisons, status_y_positions)
brackets_sero_wMelM <- get_brackets(df_wMelM, "Serotype", serotype_comparisons, serotype_y_positions)
brackets_status_wMelM <- get_brackets(df_wMelM, "Status", status_comparisons, status_y_positions)

# Debug: Check bracket data
print("Brackets Serotype wAlbB:")
print(head(brackets_sero_wAlbB))
print("Brackets Status wAlbB:")
print(head(brackets_status_wAlbB))

# 12) Plotting function with optional brackets
plot_density <- function(data, x, title, ci_data, comparisons_list = NULL, bracket_data = NULL) {
  p <- ggplot(data, aes_string(x = x, y = "Density", fill = "Serotype")) +
    geom_dotplot(binaxis = 'y', stackdir = 'center', stackratio = 0.8,
                 dotsize = 2.0, binwidth = 1/20, color = "black") +
    geom_errorbar(data = ci_data,
                  aes_string(x = x, ymin = "x1", ymax = "x3"),
                  position = position_dodge(width = 0.75),
                  width = 0.15, inherit.aes = FALSE) +
    geom_crossbar(data = ci_data,
                  aes_string(x = x, y = "ratio", ymin = "ratio", ymax = "ratio"),
                  width = 0.7, color = "black", linewidth = 0.35, alpha = 0.5, inherit.aes = FALSE) +
    scale_fill_manual(values = Serotype_colors) +
    labs(title = title,
         x = x,
         y = "Relative wolbachia density (log10)") +
    theme_classic(base_size = 15) +
    theme(
      axis.title = element_text(face = "bold"),
      axis.text  = element_text(color ="black", face = "bold"),
      legend.position = "none"
    ) +
    scale_y_continuous(limits = c(0, 4), expand = c(0,0))
  
  if (!is.null(bracket_data)) {
    p <- p + geom_bracket(
      data = bracket_data,
      aes(xmin = group1, xmax = group2, y.position = y.position, label = label),
      size = 0.3,
      tip.length = 0.005,
      label.size = 3,
      inherit.aes = FALSE
    )
  }
  
  return(p)
}

# 13) Build each of the four panels (with debugging)
p1_wAlbB  <- tryCatch({
  plot_density(df_wAlbB, "Serotype", "wAlbB", CI_serotype_wAlbB, NULL, brackets_sero_wAlbB)
}, error = function(e) print(e))
p2_wAlbB  <- tryCatch({
  plot_density(df_wAlbB, "Status", "", CI_status_wAlbB, NULL, brackets_status_wAlbB)
}, error = function(e) print(e))
p1_wMelM  <- tryCatch({
  plot_density(df_wMelM, "Serotype", "wMelM", CI_serotype_wMelM, NULL, brackets_sero_wMelM)
}, error = function(e) print(e))
p2_wMelM  <- tryCatch({
  plot_density(df_wMelM, "Status", "", CI_status_wMelM, NULL, brackets_status_wMelM)
}, error = function(e) print(e))

# Debug: Print components
print("Plot 1 wAlbB:")
print(p1_wAlbB)
print("Plot 2 wAlbB:")
print(p2_wAlbB)
print("Plot 1 wMelM:")
print(p1_wMelM)
print("Plot 2 wMelM:")
print(p2_wMelM)

# 14) Combine with patchwork
combined_plot <- (p1_wAlbB | p2_wAlbB | p1_wMelM | p2_wMelM)
print(combined_plot)

