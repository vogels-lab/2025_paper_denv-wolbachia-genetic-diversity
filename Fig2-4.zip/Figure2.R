library(tidyverse)
library(ggpubr)
library(xtable)
library(stargazer)
library(broom)
library(minpack.lm)
library(readxl)

# serotype/genotype/lineage

#setwd("~/Desktop/Extracted_data")
Dataset_final <-  readxl::read_xlsx("DENV1-4_extractedPCR_Clean.xlsx", sheet = "Sheet1")

## Define the order for viruses in each serotype ##
vec_serotype <- c("DH022", "DH021", "DH019", "DH148", "DH002", "DH006", "DH014", "DH142", "DH009",
                  "DH143", "DH141", "DH145", "DH040", "DH026", "DH131", "DH048", "DH035", "DH144",
                  "DH146", "DH147", "DH135", "DH099", "DH064", "DH060", "DH061", "DH073", "DH081",
                  "DH159", "DH071", "DH134", "DH069A", "DH156", "DH101", "DH091", "DH158", "DH161",
                  "DH087", "DH077", "DH074", "DH154", "DH105", "DH104", "DH110", "DH165", "DH102",
                  "DH167", "DH162", "DH169", "DH164", "DH168", "DH139", "DH140", "DH119", "DH114",
                  "DH118", "DH116","DH122", "DH157", "DH170", "DH149") 

## plot infection and dissemination rate ##

infection_rate <- Dataset_final %>% 
  mutate(`Infection(<38)` = as.numeric(`Infection(<38)`)) %>% 
  group_by(Virus, Mosquito_strain, Genotype) %>% 
  summarise(percentage = sum(`Infection(<38)`)/n(), 
            sample_size = n())  %>% 
  ungroup() %>% 
  mutate(Serotype = gsub("[^0-9]", "",Genotype))


dissemination_rate <- Dataset_final %>% 
  mutate(`Infection(<38)` = as.numeric(`Infection(<38)`)) %>% 
  mutate(`Dissemination(<38)` = as.numeric(`Dissemination(<38)`)) %>% 
  group_by(Virus, Mosquito_strain, Genotype) %>% 
  summarise(percentage = sum(`Dissemination(<38)`)/n(),
            sample_size = n())  %>% 
  ungroup() %>% 
  mutate(Serotype = gsub("[^0-9]", "",Genotype))



infection_rate$Mosquito_strain <- factor(infection_rate$Mosquito_strain, levels = c("WT", "wAlbB", "wMel"))


Serotype_colors <- c("#227DCB", "#b020e0", "#ffce9d","#954226")
Genotype_colors <- c("#F0F8FF", "#CBE6FD", "#85C7F4", "#4BAEF2", "#227DCB", "#0A4A7A","#f7e8ff", "#db99ff", "#b020e0", "#a300fb", "#4a0072", "#240037",  "#eb7600", "#ffb162", "#ffce9d", "#cd613c", "#954226", "#471f12")


# Define the desired Genotype order
genotype_order <- c("1I", "1II", "1III", "1IV", "1V", "1VI",
                    "2I", "2II", "2III", "2IV", "2V", "2VI",
                    "3I", "3II", "3III",
                    "4I", "4II", "4IV")

# Create a new label with Genotype in parentheses
infection_rate <- infection_rate %>%
  mutate(Virus_label = paste0(Virus, " (", Genotype, ")"),
         Genotype = factor(Genotype, levels = genotype_order))

# Order Virus_label by Genotype order, preserving order within each group
infection_rate <- infection_rate %>%
  arrange(Genotype) %>%
  mutate(Virus_label = factor(Virus_label, levels = unique(Virus_label)))

 

##dissemination_rate <- dissemination_rate %>%
##  mutate(Virus =gsub("DH069A", "DH069", Virus))


dissemination_rate$Mosquito_strain <- factor(infection_rate$Mosquito_strain, levels = c("WT", "wAlbB", "wMel"))


# Create a new label with Genotype in parentheses
dissemination_rate <- dissemination_rate %>%
  mutate(Virus_label = paste0(Virus, " (", Genotype, ")"),
         Genotype = factor(Genotype, levels = genotype_order))

# Order Virus_label by Genotype order, preserving order within each group
dissemination_rate <- dissemination_rate %>%
  arrange(Genotype) %>%
  mutate(Virus_label = factor(Virus_label, levels = unique(Virus_label)))

 

# Create a named vector for renaming the facets
serotype_labels <- c("1" = "DENV-1", "2" = "DENV-2", "3" = "DENV-3", "4" = "DENV-4")

#No genotypes in name
Figure2A <- infection_rate %>%
  mutate(
    Virus = ifelse(Virus == "DH069A", "DH069", Virus), Genotype = factor(Genotype, levels = genotype_order)) %>%
  arrange(Genotype) %>%
  ggplot(aes(x = factor(Virus, levels = rev(unique(Virus))),
             y = percentage * 100, fill = Genotype)) +
  geom_bar(stat = "identity", color = "black", size = 0.2) + 
  coord_flip() +
  scale_fill_manual(values = c("1I" =  Genotype_colors[1],
                               "1II" =  Genotype_colors[2],
                               "1III" = Genotype_colors[3],
                               "1IV" =  Genotype_colors[4],
                               "1V" = Genotype_colors[5],
                               "1VI" =  Genotype_colors[6],
                               "2I" = Genotype_colors[7],
                               "2II" =  Genotype_colors[8],
                               "2III" =   Genotype_colors[9],
                               "2IV" =  Genotype_colors[10],
                               "2V" =  Genotype_colors[11],
                               "2VI" =  Genotype_colors[12],
                               "3I" =  Genotype_colors[13],
                               "3II" =  Genotype_colors[14],
                               "3III" =  Genotype_colors[15],
                               "4I" =  Genotype_colors[16],
                               "4II" = Genotype_colors[17],
                               "4IV" =  Genotype_colors[18])) +
  facet_grid(Serotype ~ Mosquito_strain, scales = "free_y", space = "free_y", 
             labeller = labeller(Mosquito_strain = c("wMel" = "wMelM"), Serotype = as_labeller(serotype_labels))) + 
  theme_classic() +
  ylab("Infection (%)") + xlab("Virus") +
  theme(panel.border = element_blank(), 
        axis.line = element_line(colour = "black"),
        plot.title = element_text(face="bold", hjust = 0.5),
        axis.text.x = element_text(color="black", size = 12),
        axis.text.y = element_text(color="black", size= 12),
        text = element_text(size = 12))




Figure2B <- dissemination_rate %>%
  mutate(
    Virus = ifelse(Virus == "DH069A", "DH069", Virus), Genotype = factor(Genotype, levels = genotype_order)) %>%
  arrange(Genotype) %>%
  ggplot(aes(x = factor(Virus, levels = rev(unique(Virus))),
             y = percentage * 100, fill = Genotype)) +
  geom_bar(stat = "identity", color = "black", size = 0.2) + 
  coord_flip() +
  scale_fill_manual(values = c("1I" =  Genotype_colors[1],
                               "1II" =  Genotype_colors[2],
                               "1III" = Genotype_colors[3],
                               "1IV" =  Genotype_colors[4],
                               "1V" = Genotype_colors[5],
                               "1VI" =  Genotype_colors[6],
                               "2I" = Genotype_colors[7],
                               "2II" =  Genotype_colors[8],
                               "2III" =   Genotype_colors[9],
                               "2IV" =  Genotype_colors[10],
                               "2V" =  Genotype_colors[11],
                               "2VI" =  Genotype_colors[12],
                               "3I" =  Genotype_colors[13],
                               "3II" =  Genotype_colors[14],
                               "3III" =  Genotype_colors[15],
                               "4I" =  Genotype_colors[16],
                               "4II" = Genotype_colors[17],
                               "4IV" =  Genotype_colors[18])) +
  facet_grid(Serotype ~ Mosquito_strain, scales = "free_y", space = "free_y", 
             labeller = labeller(Mosquito_strain = c("wMel" = "wMelM"), Serotype = as_labeller(serotype_labels))) + 
  theme_classic() +
  ylab("Dissemination (%)") + xlab("Virus") +
  theme(panel.border = element_blank(), 
        axis.line = element_line(colour = "black"),
        plot.title = element_text(face="bold", hjust = 0.5),
        axis.text.x = element_text(color="black", size = 12),
        axis.text.y = element_text(color="black", size= 12),
        text = element_text(size = 12))

print(Figure2A)
print(Figure2B)
